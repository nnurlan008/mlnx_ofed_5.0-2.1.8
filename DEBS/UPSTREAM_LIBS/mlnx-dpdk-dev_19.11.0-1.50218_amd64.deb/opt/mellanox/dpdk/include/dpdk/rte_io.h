/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2016 Cavium, Inc
 */

#ifndef _RTE_IO_X86_H_
#define _RTE_IO_X86_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "generic/rte_io.h"

#ifdef __cplusplus
}
#endif

#endif /* _RTE_IO_X86_H_ */
