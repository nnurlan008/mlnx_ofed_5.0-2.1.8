/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2019 Arm Limited
 */

#ifndef _RTE_MCSLOCK_X86_64_H_
#define _RTE_MCSLOCK_X86_64_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "generic/rte_mcslock.h"

#ifdef __cplusplus
}
#endif

#endif /* _RTE_MCSLOCK_X86_64_H_ */
